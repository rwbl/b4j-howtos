-B4J Project B4JHowToSQLite
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtosqlite.zip|B4JHowTo-SQLite (B4J Open Source)>

-Description
This App is an example of using B4J SQLite database.
The database "items.db" has two tables "items" and "categories":
Table Items:
CREATE TABLE [items] ([ID] INTEGER PRIMARY KEY, [Title] TEXT, [Category] TEXT, [Changed] TEXT, [Content] TEXT);
Table Categories:
CREATE TABLE [categories] ([ID] INTEGER PRIMARY KEY, [Category] TEXT);

The items are shown on the mainform in a tableview and a textarea.
The items and the categories are managed in seperate forms. The database routines are in defined in a class "dbmod".
The B4J class dbutils is also used.
To display messages, a message form is included accepting HTML in the message content.

The form Items makes use of the JavaFX 8 datepicker. 

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
* Libararies used: JavaObject
* ToDo: See project file ToDo region

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20140629
(+) First version
