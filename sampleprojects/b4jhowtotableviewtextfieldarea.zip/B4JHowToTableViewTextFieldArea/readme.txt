-B4J Example roContactZ
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/opensource/rocontactz.zip|roContactZ (B4J Open Source)>

-Description
roContactZ - a B4J Example app.
Manage contacts in  SQLite database. Contacts are listed in a listview.
Shows usage of SQLite database, a listview, toolbar with buttons, textfile handling.

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
Copy the library jRLUtils (jar and xml) to your B4J additional libraries folder.

More to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Screenshot
<#b4j/opensource/rocontactz.png>

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20140205
(+) Extras > Find Name
(*) Compiled using B4J v1.5
20140126
(*) Minor changes
20140125
(+) Added icons to the buttons
(*) Changed listview selected row from red to yellow
20140109
(+) Export Addresslist HTML
(+) Save and restore column positions
(*) Set mainform w & h to 500
(-) Library RLUtils not required anymore as using methods from the standard B4J jFX library
(-) Label Hint replaced by ShowMessage
20131210
(+) Export address in vCard format
(*) Various smaller improvements; added more comments in the code
20131207
(*) Modalform AboutForm replaced by MessageForm (modified version)
(*) Using CSS files for mainform and messageform (not all controls embedded yet)
20131205
(*) Updated using BJ4 v1.00
20131124
(+) First Version
