B4J HowTo create a toolbar using javaobjects.
Toolbar: [BUTTON][BUTTON][TEXTFIELD][LABEL][BUTTON]
20160608 by rwblinn.de
