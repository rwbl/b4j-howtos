-B4J Project B4JHowTo-PlayMedia
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
These apps are made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtoplaymedia.zip|PlayMedia - Simple MP3 or MP4 Media Player (B4J Open Source)>

-Description
This is an example project to show how to play mp3 (sound) or mp4 (video) media files using the B4J media player class.

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
* This WebApp requires B4J v2.2 or higher.
* To learn more, read the source files. These are well commented.
* Additional Libraries: jSQL.
* Ensure to copy the jar & xml files to the B4J Additional Libraries Folder.
* ToDos are captured in the b4j project file.

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20140710
(*) Minor bug fixes and improvements
20140623
(+) First version
