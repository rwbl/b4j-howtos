-B4J Project B4JHowToTableViewDB
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.b4x.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtotableviewdb.zip|B4JHowToTableViewDB (B4J Open Source)>

-Description
Some example projects to show loading SQLite tables in TableView(s).
Projects:
OneTable - One table CONTACTS from database contacts.db.
TwoTables - Two tables CONTACTS and CONTACTHISTORY from database contacts.db. One contact can have one or more contacthistory entries. CONTACTHISTORY.Name = CONTACT.ID.

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
* Libraries used: jSQL
* AdditionalJar: sqlite-jdbc-3.8.6

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
20150118
NEW:First Version
