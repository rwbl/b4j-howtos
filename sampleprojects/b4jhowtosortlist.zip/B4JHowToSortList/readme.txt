-B4J Example B4JHowTo-SortList
Copyright (c) 2015 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!www.b4x.com/b4j.html|here> .

-Download
* <!file://b4j/opensource/b4jhowtosortlist.zip|B4JHowToSortList (B4J Open Source)>

-Description
Shows how to sort a list using Type. In addition how to store to and load from a file.
The list is displayed in a standard JavaFX listview control.

-Installation
Unpack the zip file and load the b4j project file in the B4J IDE.

-Notes
More to find <!http://www.rwblinn.de|here> .

-Screenshot

-Change Log
20150630
NEW:First Version