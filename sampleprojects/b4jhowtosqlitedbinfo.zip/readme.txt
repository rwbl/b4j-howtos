-B4J Project B4JHowToSQLiteDBInfo
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.b4x.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtosqlitedbinfo.zip|B4JHowToSQLiteDBInfo (B4J Open Source)>

-Description
Select an SQLite Database and show information about the database including tableinfo.

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
* Libraries used: jSQL
* AdditionalJar: sqlite-jdbc-3.8.6

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
20151006
UPD:Reviewed and improved all Subs
20150125
NEW:First Version
