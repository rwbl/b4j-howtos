-B4J HOWTO Project Inline Java
Copyright (c) 2015 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
These apps are made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
THIS SOFTWARE IS PROVIDED TO YOU "AS IS". WITHOUT WARRENTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. WE EXPRESSLY DISCLAIM ANY LIABILITY WHATSOEVER FOR ANY DIRECT, INDIRECT,
CONSEQUENTIAL, INCIDENTAL OR SPECIAL DAMAGES, INCLUDING, WITHOUT LIMITATION, LOST REVENUES, LOST PROFITS, LOSSES RESULTING FROM BUSINESS
INTERRUPTION OR LOSS OF DATA, REGARDLESS OF THE FORM OF ACTION OR LEGAL THEORY UNDER WHICH THE LIABILITY MAY BE ASSERTED, EVEN IF ADVISED OF THE
POSSIBILITY OR LIKELIHOOD OF SUCH DAMAGES.

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtoinlinejava.zip|B4J Inline Java Examples (B4A & B4J Open Source)>

-Various Inline Java Examples
See the respective folders for more info.

#Additional Notes
* Requires B4J v2.8 or higher, Additional Libraries: javaobject
* Logging is done extensively using Sub AppLog; set flag CAPPLOG to false to turn logging off.
* To learn more, read the readme and source files. These are well commented.

#Installation
Unpack the zip file, select the project B4A or B4J and load accordingly in th IDE.

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
20150729
NEW:Classes folder with examples calling methods from classes
20150712
NEW:jSoup strip HTML Tags example (jSoupEx5)
20150405
NEW: Many new examples - see folder structure
20150224
NEW:First version
