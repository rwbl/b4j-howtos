-B4J Example B4JHowTo-SQLiteBLOB
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtosqliteblob.zip|B4JHowTo-SQLite App to show inserting Blobs (B4J Open Source)>

-Description
B4JHowTo project to test SQLite Blob functionality.
This is an app to manage any text items - simple database with one table and two fields ID (INT) and Title (TEXT)
Table SQL Create Statement: CREATE TABLE If Not EXISTS Images (ID INTEGER PRIMARY KEY, Title TEXT , Image BLOB).
The listview is customized were each line is an anchorpane holding a label. The label text shows the Title. The label tag holds the ID. The ID is used to delete the selected entry.

Functionality:
* Select and Insert a Blob in a SQLite database Images.db
* Delete selected Entry
* Clear all entries
* Resize the image using horizontal slider in a range between 100 and 200dip

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
More to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20141124
(+) First Version.
