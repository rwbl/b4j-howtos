B4J HowTo MQTT broker with B4X Clients.
@version 20170702 by Robert W.B. Linn @ www.rwblinn.de.

A B4J Non-UI application runs on a Raspberry Pi (RPi) as MQTT Broker.
Various B4X MQTT clients are publishing in regular interval messages and subscribing to messages.

Applications:
#B4JBroker
Runs on the RPi with IP address:Port = tcp://RPi-IP-Address:51041.

#B4AClient
Runs on Android device.
Subscribes to selective topics.
Publish Topic = MQTT/B4AClient
Subscribe Topic1 = MQTT/B4JClient1
Subscribe Topic2 = MQTT/B4JClient2

#B4JClient1
Runs on PC.
Subscribes to selective topics.
Publish Topic = MQTT/B4JClient1
Subscribe Topic1 = MQTT/B4JClient2
Subscribe Topic2 = MQTT/B4AClient1

#B4JClient2
Runs on PC.
Subscribes to all messages published.
Publish Topic = MQTT/B4JClient2"
Subscribe Topic = MQTT/#

#B4JBrowser
Runs on the RPi.
Subscribes to all messages published, which are listed in Browser TextArea. Access the application http://RPi-IP-Address:51042.
Subscribe Topic = MQTT/#

#B4RClient
Runs on an Arduino or ESP8266. 
Subscribes to all messages published, which are shown on an OLED display.
Note: Tested using a ESP8266 Wemos D1. If first time MQTT is not working thenr reset the device.
PublishTopic = "MQTT/B4RClient"
SubscribeTopic = "MQTT/#"
