<?
$host = "hostname";
$db = "databasename";
$user = "username";
$pw = "password";
?>
