-B4J Project B4JHowTo-mySQLRemote
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtomysqlremote.zip|B4JHowTo-mySQLRemote (B4J Open Source)>

-Description
This App is an example of using B4J to access a remote mySQL database and show the records in a tableview.
Beyond selecting records, this app enables to insert, update, delete, export and import records.

How it works?
The remote mySQL database is accessed from the B4J app using a Httpjob. The Httpjob sends a request to the server, which is being picked up by a php script (which has been passed as a parameter by the Httpjob).
The php script connects to the database and executes the request as given by the B4J app. The result of the request is passed from the php script back to the B4J app in JSON format.
The B4J app handles the result by the Httpjob Jobdone event.

More specifics on Httpjob requests from B4J to the Remote Server:
* All Httpjobs have same setup: init the http job first and the execute postdownload2.
* The Httpjob Event Jobdone will handle the result of the server php script.
* IMPORTANT: Download2 (which submits a HTTP GET request) is used to ensure parameters are escaped (Encodes illegal parameter characters).
* More http://www.basic4ppc.com/b4j/help/jhttputils2.html#httpjob_download2

What is required?
1. A remote mySQL Database & Table
mySQL Database Table Structure
Tablename: Notes
Tablestructure: ID Int(11), Title varchar(100), Category varchar(20), Content text
The field ID is the primary key and auto incremented.
The database and the table must exist. They will not be crearted if not found!

2. A remote php script to handle the B4J requests
a. Copy mysqlremote.php (included in the zip file) to your server
b. Amend the B4J project file: Define the url to access mysqlremote.php in the var urlbase in Process_Globals
c. On the server create a file mysqlremoteconnect.php with the connection parameters (info see mysqlremote.php as being included):
<?
$host = "hostname";
$db = "databasename";
$user = "username";
$pw = "password";
?>

Some default SQL statements:
CREATE TABLE IF NOT EXISTS Notes (
  ID int(11) NOT NULL AUTO_INCREMENT,
  Title varchar(100) NOT NULL,
  Category varchar(20) NOT NULL,
  Content text COLLATE NOT NULL,
  PRIMARY KEY (ID)
)
SELECT * FROM Notes WHERE 1
SELECT ID, Title, Category, Content FROM Notes WHERE 1
INSERT INTO Notes(ID, Title, Category, Content) VALUES ([value-1],[value-2],[value-3],[value-4])
DELETE FROM Notes WHERE 1
CHECK TABLE Notes

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
* Additional Libararies used: jHTTPUtils2, Json
* ToDo: See project file ToDo region

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20140711
(+) First version
