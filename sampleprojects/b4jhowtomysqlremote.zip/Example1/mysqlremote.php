<?
// File:
// mysqlremote.php 
// Purpose:
// PHP script to access a remote mySQL database and select records
// URL examples to access:
// Select rows:	http://www.rwblinn.de/b4j/b4jhowto/aprogress/b4jhowtomysqlremote/mysqlremoteselect.php?action=select"
// Notes:
// Remove print statements if wanted to fetch result from select statement except the one for print json_encode($rows);
// Define the connection parameter in the file mysqlremoteconnect.php and ensure stored on the server in same location as mysqlremote.php
// Changed:
// 20140708

// print ("<H1>B4JHowTo-mySQLRemoteSelect</H1><HR>");
$today = date("Y-m-d H:i:s"); 
// print ("$today <BR>");

// Retrieve the parameter
// Get the action and the content fields. these will be used based upon the action
$action = $_GET["action"];
$where = $_GET["where"];
$id = $_GET["id"];
$title = $_GET["title"];
$category = $_GET["category"];
$content = $_GET["content"];

// print ("Action: $action <BR>");

// Set the database parameter to connect
// Define the include file: $host, $db, $user, $pw
include ("mysqlremoteconnect.php");

// Connect to the db
$con = mysql_connect($host,$user,$pw) or die("Error " . mysql_error($con));
mysql_select_db($db) or die("Error " . mysql_error($con));
mysql_query("SET CHARACTER SET utf8");

// Check command and execute accordingly

// SELECT - Result = the selected rows in JSON format
if ($action == 'select') {
	// Define the sql command
	$sql = "SELECT ID, Title, Category, Content FROM Notes ORDER BY ID";
	if (strlen($where) > 0) {
		$sql = sprintf("SELECT ID, Title, Category, Content FROM Notes WHERE %s ORDER BY ID", mysql_real_escape_string($where));
	}
	// There are various ways to get the rows, see below BUT for this the JSON result is being used.
	// See also mysql_result(), mysql_fetch_array(), mysql_fetch_row(), etc.
	$result = mysql_query($sql);
	$rows = array();
  while($r = mysql_fetch_assoc($result)) {
  	$rows[] = $r;
  }
  print json_encode($rows);
}

// INSERT - Result = Info if insert been successful or not
// Example run from Browser using special chars in the content field:
// http://www.rwblinn.de/b4j/b4jhowto/aprogress/b4jhowtomysqlremote/mysqlremote.php?action=insert&title=T10&category=C3&content=X'1'23
if ($action == 'insert') {
	// Define the sql command
	// print ("Inserted:<HR> $title , $category , $content <HR>");
	$sql = sprintf("INSERT INTO Notes (ID, Title, Category, Content) VALUES(NULL, '%s', '%s', '%s')",
            mysql_real_escape_string($title),
            mysql_real_escape_string($category),
            mysql_real_escape_string($content));
	$result = mysql_query($sql);
  print ("Result: " . $result . "<BR>");
	if (mysql_errno()) {
    header("HTTP/1.1 500 Internal Server Error");
    echo $query.'<BR>';
    echo mysql_error();
	}	
}

// UPDATE - Result = Info if update been successful or not
// Example run from Browser using special chars in the content field:
// http://www.rwblinn.de/b4j/b4jhowto/aprogress/b4jhowtomysqlremote/mysqlremote.php?action=insert&title=T10&category=C3&content=X'1'23
if ($action == 'update') {
	// Define the sql command
	// print ("Updated:<HR> $title , $category , $content <HR>");
	$sql = sprintf("UPDATE Notes set Title='%s', Category='%s', Content='%s' WHERE ID=%s",
            mysql_real_escape_string($title),
            mysql_real_escape_string($category),
            mysql_real_escape_string($content),
            mysql_real_escape_string($id));
	$result = mysql_query($sql);
  print ("Result: " . $result . "<BR>");
	if (mysql_errno()) {
    header("HTTP/1.1 500 Internal Server Error");
    echo $query.'<BR>';
    echo mysql_error();
	}	
}

// DELETE - Result = Info if delete been successful or not
if ($action == 'delete') {
	// Define the sql command
	$sql = sprintf("DELETE FROM Notes WHERE ID=%s",
            mysql_real_escape_string($id));
	$result = mysql_query($sql);
  print ("Result: " . $result . "<BR>");
	if (mysql_errno()) {
    header("HTTP/1.1 500 Internal Server Error");
    echo $query.'<BR>';
    echo mysql_error();
	}	
}

// CLEAR - Result = Info if delete been successful or not
if ($action == 'clear') {
	// Define the sql command
	$sql = sprintf("DELETE FROM Notes");
	$result = mysql_query($sql);
  print ("Result: " . $result . "<BR>");
	if (mysql_errno()) {
    header("HTTP/1.1 500 Internal Server Error");
    echo $query.'<BR>';
    echo mysql_error();
	}	
}

// EXPORT - Result = Info if delete been successful or not
if ($action == 'export') {
	// Define the sql command
	$sql = sprintf("SELECT * FROM Notes ORDER BY ID");
	$result = mysql_query($sql);
	$rows = array();
  while($r = mysql_fetch_assoc($result)) {
  	$rows[] = $r;
  }
  print json_encode($rows);
	if (mysql_errno()) {
    header("HTTP/1.1 500 Internal Server Error");
    echo $query.'<BR>';
    echo mysql_error();
	}	
}

?>
