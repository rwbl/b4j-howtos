B4J HowTo - Raspberry Pi MySQL accessed by B4J UI application using jRDC2
v2016.05.27 by rwblinn.de

-Raspberry Pi MySQL Setup
* MySQL running on RPi with IP 192.168.0.58.
* RDC folder on the RPi /home/pi/b4j/rdc
A full example of creating a MySQL table called 'notes', inserting some records, select records.
The MySQL commands have been entered in a MySQL session via Putty Terminal to access the Raspberry Pi (RPi).

login as: pi
pi@58:~ $ mysql -uroot -hlocalhost -p                                        
mysql> CREATE DATABASE notes;
mysql> CREATE USER 'notesuser'@'localhost' IDENTIFIED BY 'nu';
mysql> GRANT ALL PRIVILEGES ON notes.* TO 'notesuser'@'localhost';
mysql> FLUSH PRIVILEGES;
mysql> exit
pi@58:~ $ mysql -unotesuser -hlocalhost notes -p
mysql> CREATE TABLE notes (id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,description VARCHAR(50),content VARCHAR(255), created TIMESTAMP DEFAULT NOW());
mysql> INSERT INTO notes(description,content) VALUES ('Note 1', 'The content of note 1.');
mysql> INSERT INTO notes(description,content) VALUES ('Note 2', 'The content of note 2.');
mysql> SELECT * FROM  notes;
+----+-------------+------------------------+---------------------+
| id | description | content                | created             |
+----+-------------+------------------------+---------------------+
|  1 | Note 1      | The content of note 1. | 2016-05-26 11:32:18 |
|  2 | Note 2      | The content of note 2. | 2016-05-26 11:32:29 |
+----+-------------+------------------------+---------------------+

-Class jRDC2
Reference https://www.b4x.com/android/forum/threads/class-jrdc2-b4j-implementation-of-rdc-remote-database-connector.61801/
Changes to original code:
Config.properties file: Set the location to File.DirApp instead if File.DirAssets to be flexible in changing the configuration with rebuild the class.

Read the config.properties file located in the dirapps folder.

Example output running jRDC2
2016-05-27 09:22:59.225:INFO::main: Logging initialized @579ms
May 27, 2016 9:22:59 AM com.mchange.v2.log.MLog <clinit>
INFO: MLog clients using java 1.4+ standard logging.
May 27, 2016 9:22:59 AM com.mchange.v2.c3p0.C3P0Registry banner
INFO: Initializing c3p0-0.9.2.1 [built 20-March-2013 11:16:28 +0000; debug? true; trace: 10]
2016-05-27 09:23:00.390:INFO:oejs.Server:main: jetty-9.3.z-SNAPSHOT
2016-05-27 09:23:00.565:INFO:oejsh.ContextHandler:main: Started o.e.j.s.ServletContextHandler@1c7cbad{/,file:///home/pi/tempjars/www,AVAILABLE}
2016-05-27 09:23:00.574:INFO:oejs.AbstractNCSARequestLog:main: Opened /home/pi/tempjars/logs/b4j-2016_05_27.request.log
2016-05-27 09:23:00.615:INFO:oejs.ServerConnector:main: Started ServerConnector@be92ad{HTTP/1.1,[http/1.1]}{0.0.0.0:17178}
2016-05-27 09:23:00.617:INFO:oejs.Server:main: Started @1983ms
jRDC is running (version = 2.11)
May 27, 2016 9:41:32 AM com.mchange.v2.c3p0.impl.AbstractPoolBackedDataSource getPoolManager
INFO: Initializing c3p0 pool... com.mchange.v2.c3p0.ComboPooledDataSource [ acquireIncrement -> 3, acquireRetryAttempts -> 30, acquireRetryDelay -> 1000, autoCommitOnClose -> false, automaticTestTable -> null, breakAfterAcquireFailure -> false, checkoutTimeout -> 20000, connectionCustomizerClassName -> null, connectionTesterClassName -> com.mchange.v2.c3p0.impl.DefaultConnectionTester, dataSourceName -> 1m9g1uw881vtc3epm|104e3b2, debugUnreturnedConnectionStackTraces -> false, description -> null...
 maxStatementsPerConnection -> 0, minPoolSize -> 3, numHelperThreads -> 3, preferredTestQuery -> null, properties -> {user=******, password=******}, propertyCycle -> 0, statementCacheNumDeferredCloseThreads -> 0, testConnectionOnCheckin -> false, testConnectionOnCheckout -> true, unreturnedConnectionTimeout -> 0, userOverrides -> {}, usesTraditionalReflectiveProxies -> false ]
Command: query: select3, took: 1623ms, client=192.168.0.4
Command: query: select3, took: 44ms, client=192.168.0.4

-B4J UI application RDCClientUI
#Functionality:
* CRUD (Create, Read, Update, Delete) operations from the Remote MySQL database (defined in jRDC2 config.properties)
* Show the records in a tableview, set initial tableview message.
* Toastmessage dialog when waiting for database operation to complete (Library jRLDialogs8)
* Toolbar used for the buttons (created using JavaObject)
* Set styling for buttons & toolbar (Library CSSUtils)
* Set styling for tooltips (external CSS file in the dirassets folder)

#Class DBRequestManager
Changes to original code:
Modified Image handling by setting conditional defines for B4A and B4J.

#Source
Read the source code which is well documented.

-B4J Bridge
While developing, the B4J Bridge was running on the RPi. Ensure to copy the config.properties to the tempjards folder.
Hint: Create the tempjars folder as user Pi, which makes it easier to copy the update config.properties file.

