-B4J Project B4JHowToWebApp-SendMail
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
These apps are made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtowebappsendmail.zip|SendMail - Simple WebServer based Mail Sender (B4J Open Source)>

-Description
This is an example project to show how to sent mails via webserver using jQuery Mobile (jQM).
This Webapp makes use of jQM dialogs instead of seperate HTML pages. The jQM dialogs are defined in index.html.
Read sendmail.bas and www/index.html for detailed information.
#Background
The background of developing this simple mail sender, is to build a B4J based webserver app which checks at regular intervals processes on a Raspberry Pi.
If a process has stopped, an email is automatically sent to a specific email address to notify.

-How the it works?
After starting the webserver, it waits for connections from clients via webbrowser.
When the webapp is accessed via webbrowser, the file index.html is loaded. Index.html opens the websocket defined in sendmail.b4j & bas.
SendMail.bas handles the events which are triggered from the buttons:
Send Mail: Composes the mail using subject and body, and sends to the receipient as defined in the To field.
Configuration: Configure the SMPT parameter. 
About: Information about this WebApp.

-Configuration
The file webappsendmail.json in the object folder hold the configuration. It has a JSON structure:
[
  {
    "password": "PASSWORD",
    "port": "25",
    "receipient": "receipient@name.com",
    "mailserver": "smtp.strato.de",
    "username": "user@name.com"
  }
]

When accessing the server, the receipient is set in the field "To".

-Start the WebServer (Testmode)
Option 1: Start B4J, open WebAppSendMail.b4j and then run from the IDE
Option 2: From a console, start the jar file located in the Objects folder using command: java -jar WebAppSendMail.jar.

-Access from Client
From your webbrowser: Enter as URL: localhost:51042.
From another computer in the network, use http://ipaddress:51042 (like http://192.168.0.10:51042).

-Additional Notes
Installing on a webserver ensure to copy the www folder content. This folder contains all html related files.
Logging is done extensively using Sub AppLog; set flag CAPPLOG (teem.b4j) to false to turn logging off
Find further hints in the B4J HOWTOs http://www.rwblinn.de/b4j/b4jhowto/index.htm

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
* This WebApp requires B4J v2.2 or higher.
* To learn more, read the source files. These are well commented.
* Additional Libraries: jSQL.
* Ensure to copy the jar & xml files to the B4J Additional Libraries Folder.
* ToDos are captured in the b4j project file.

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20140702
(*) Upgraded jQuery Mobile 1.4.2 to 1.4.3
20140622
(+) First version
