-B4J Example B4JHowToCustomizedListView
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/opensource/b4jhowtocustomizedlistview.zip|B4JHowToCustomizedListView (B4J Open Source)>

-Description
B4JHowToCustomizedListView - a B4J Example app.
Manage knowledge base like information.
Shows usage of a customized listview.
The source is well commented - a lot of tips to be found.

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
More to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Screenshot

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20140106
(+) Started to develop prototype.