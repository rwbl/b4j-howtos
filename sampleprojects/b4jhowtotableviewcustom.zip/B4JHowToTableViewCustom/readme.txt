-B4J Project B4JHowToTableViewCustom
Copyright (c) 2015 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
These apps are made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
THIS SOFTWARE IS PROVIDED TO YOU "AS IS". WITHOUT WARRENTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. WE EXPRESSLY DISCLAIM ANY LIABILITY WHATSOEVER FOR ANY DIRECT, INDIRECT,
CONSEQUENTIAL, INCIDENTAL OR SPECIAL DAMAGES, INCLUDING, WITHOUT LIMITATION, LOST REVENUES, LOST PROFITS, LOSSES RESULTING FROM BUSINESS
INTERRUPTION OR LOSS OF DATA, REGARDLESS OF THE FORM OF ACTION OR LEGAL THEORY UNDER WHICH THE LIABILITY MAY BE ASSERTED, EVEN IF ADVISED OF THE
POSSIBILITY OR LIKELIHOOD OF SUCH DAMAGES.

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtotableviewcustom.zip|TableView Customized Examples (B4J Open Source)>

-Description
Various customized TableView Examples. 
Standard: Create a TableView with 2 columns, 3 values and totals
Customized: Create a TableView with 2 columns (Label/Label), 3 values and totals
Customized: Create a TableView with 2 columns (Label wrapped/Label wrapped), 3 values and totals
Customized: Create a TableView with 2 columns (Label/TextField), 3 values and totals
Customized: Create a TableView with 1 columns (Image/TextField)
Customized: Create a TableView with 1 column (CheckBox), 3 rows
Lookup in the b4j for additional examples.

#Additional Notes
* Requires B4A 4.0 & B4J v2.5 or higher, Additional Libraries: javaobject
* To learn more, read the readme and source files. These are well commented.

#Installation
Unpack the zip file and load the b4j file in B4J.

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
20150129
NEW:First version
