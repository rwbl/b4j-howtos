-B4J Example B4JHowTo-SQLite2
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtosqlite2.zip|B4JHowTo-SQLite App to manage any text items (B4J Open Source)>

-Description
B4JHowTo project to test some basic SQLite functionality showing also advanced usage of various JavaFX controls.
This is an app to manage any text items - simple database with one table and two fields. Shows also how to use images in buttons and menuitems.
Functionality:
* Insert, update, delete text items in a SQLite database anyitems.db
* Export items to a textfile per item
* Import items from a textfile per item
* Delete all items
* Settings form for sorting the list
* Special functions, like Insert new from clipboard, insert date in description, refresh list, send item as e-mail, export to HTML

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
More to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20140730
(*) Export improved using sql resultset instead of looping over listview
20140716
(+) Complete reworked.
20140629
(+) First Version.
