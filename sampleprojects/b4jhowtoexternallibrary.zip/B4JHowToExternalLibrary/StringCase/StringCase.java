package de.rwblinn.stringcase;
// Compile: "c:\Program Files (x86)\Java\jdk8\bin\javac" StringCase.java

public class StringCase {

	public static final String Version = "20180531";
	
	/**
	 * Convert String to UPPERCASE
	 * @param String
	 * @return String in UpperCase
	 */
	public static String ToUpperCaseEx(String s){
		return s.toUpperCase();
	}
	
	/**
	 * Convert String to lowercase
	 * @param String
	 * @return String in lowercase
	 */
	public static String ToLowerCaseEx(String s){
		return s.toLowerCase();
	}


}
