-B4J Project B4JHowToWebAppTaskMgr
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtowebapptaskmgr.zip|B4JHowToWebAppTaskMgr (B4J Open Source)>

-Description
This is an example project to show the B4J WebApp functionality based upon WebSockets.
It is a Task manager using HTML for the client to access the server.
The tasks are stored in a SQLite database, which is managed by the B4J WebServer.
Read b4jhowtowebapptaskmgr.b4j for more information.

To start:
Load taskmgr.b4j and then run OR start from the Objects folder java -jar taskmgr.jar.
Access the task list by opening a webbrowser and enter localhost:51042.
To access from another computer in the network, use its http://ipaddress:51042 (like http://192.168.0.10:51042).

How it works:
After starting the webserver and accessing by using http://ipaddress:51042, the HTML file /objects/index.html is loaded.
Index.html actions the handler taskmgr.bas.
The taskmgr.bas handler selects the records from the database taskmgr.db (in the objects folder) using jQuery and updates the embedding task table.
Buttons:
Add: adds a new task to the taskmgr.db
Update: updates the selected task to the taskmgr.db
Delete: deletes the selected task from the taskmgr.db
Delete All: delete all tasks from the taskmgr.db
About: Information about this WebApp TaskMgr

The Files:
TaskMgr.b4j: Project file
TaskMgr.bas: The main task manager module
license.txt: Mozilla Lic
readme.txt: This file
DBUtils.bas: Util subs to handle SQLite DB management (CRUD)
WebUtils.bas: Util subs to handle web relation functions

Objects\taskmgr.db: The task manager database
Objects\taskmgr.db-shm: wal-index shared memory file
Objects\taskmgr.db-wal: write-ahead log file
Objects\TaskMgr.jar: The task manager jar

Objects\logs\: Log files

Objects\www\b4j_ws.js: B4J WebSockets client library (communication between the server and the client.)
Objects\www\index.css: CSS file for index.html
Objects\www\index.html: Index file loaded by the webclient when accessing the task manager

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
* This WebApp example is based upon B4J v2.x.
* To learn more, read the source files. These are well commented.
* Additional Libraries: jSQL.
* Ensure to copy the jar & xml files to the B4J Additional Libraries Folder.
* To edit html, css files etc. I am using UltraEdit (www.ultraedit.com), but NotePad++ (www.notepad-plus-plus.org) is a freeware alternative.

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20140516
(+) Copy button
(*) Layout modifications 
(*) Various minor improvements

20140430
(*) Confirm Dialogs for Delete Task and Delete All Tasks replaced from standard JavaScript to jQuery UI dialogs (see index.html)
(*) Various minor improvements

20140429
(+) Copy task details to clipboard via jQuery UI Input Dialog
(*) Various minor improvements

20140416
(+) JavaScript based dialogs Alert, Confirm, Input. Used f.e. for Deleting a or all tasks
(+) Show current date far right in the toolbar
(*) Transaction handling in DBUtils to manage concurrent DB access
(*) Various minor improvements

20140413
(+) First version
