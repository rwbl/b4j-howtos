# B4J Project TeeM
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany.
These apps are made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).

**NOTE** This sample application is from 2014 and is not maintained anymore.

## Description
This webapp, called teem, is a team event manager.
The request was to manage team events from Android, iPhone, Windows and Linux (Raspberry) devices.
The solution is a B4J Webapp based on jQuery Mobile with an underlying SQLite database accesible via browser.
This Webapp makes extensive use of jQuery Mobile dialogs instead of seperate HTML pages. The jQM dialogs are defined in index.html.
The database teem.db contains the two tables Events and Members.
Read teem.b4j, teem.bas and www/index.html for detailed information.

## Start the WebServer (teem.jar file) and the Team Manager
Load teem.b4j and then run OR start the jar file from the Objects folder java -jar teem.jar.
Access the team event list by opening a webbrowser and enter localhost:51042.
To access from another computer in the network, use its http://ipaddress:51042 (like http://192.168.0.10:51042).

## How the Team Manager works?
After starting the webserver, the database is initialized. If the database does not exists, it will be created and stored in the webapp folder.
When the webapp is accessed via webbrowser, the file index.html is loaded. Index.html opens the websocket defined in teem.bas.
The teem.bas handler selects the records from the database teem.db (in the objects folder), table Events and updates the events table (using JavaScript).

## Buttons
Login: Login as Manager or Team Member using username as defined in Table Members. Note: Field Password is not used.
About: Information about this WebApp TeeM.
Events: Manage Events (add, update, delete).
Members: Manage Members (add, update, delete).

Additional Notes
	Installing on a webserver ensure to copy the www folder content. This folder contains all html related files including jQM.
	Clicking on Date or Time, a Date/Time picker is shown based upon DateBox, a Date and Time Picker plugin for jQueryMobile (http://dev.jtsage.com/jQM-DateBox/).
	Logging is done extensively using Sub AppLog; set flag CAPPLOG (teem.b4j) to false to turn logging off

## Installation
Unpack the zip file and load the b4j file in B4J.

## Notes
* This WebApp requires B4J v2.2 or higher.
* To learn more, read the source files. These are well commented.
* Additional Libraries: jSQL.
* Ensure to copy the jar & xml files to the B4J Additional Libraries Folder.
* To edit html, css files etc. I am using UltraEdit (www.ultraedit.com), but NotePad++ (www.notepad-plus-plus.org) is a freeware alternative.

## Change Log
(+) New, (*) Improved, (-) Removed
20140527
(*) Bug fixes

20140526
(+) First version
