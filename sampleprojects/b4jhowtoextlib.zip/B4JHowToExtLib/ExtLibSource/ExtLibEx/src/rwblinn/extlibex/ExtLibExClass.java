package rwblinn.extlibex;

public class ExtLibExClass {

	public static final String version = "20150717";
	
	/**
	 * Convert String to UPPERCASE
	 * @param String
	 * @return String in UpperCase
	 */
	public static String ToUpperCaseEx(String s){
		return s.toUpperCase();
	}
	
	/**
	 * Convert String to lowercase
	 * @param String
	 * @return String in lowercase
	 */
	public static String ToLowerCaseEx(String s){
		return s.toLowerCase();
	}


}
