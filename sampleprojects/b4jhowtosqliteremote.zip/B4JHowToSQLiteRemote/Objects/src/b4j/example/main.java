package b4j.example;

import anywheresoftware.b4a.BA;

public class main extends javafx.application.Application{
public static main mostCurrent = new main();
public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.main", null);
		ba.loadHtSubs(main.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.main", ba);
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}

 
    public static void main(String[] args) {
    	launch(args);
    }
    public void start (javafx.stage.Stage stage) {
        try {
            anywheresoftware.b4j.objects.FxBA.application = this;
		    anywheresoftware.b4a.keywords.Common.Density = (float) javafx.stage.Screen.getPrimary().getDpi() / 96f;
            BA.Log("Program started.");
            initializeProcessGlobals();
            anywheresoftware.b4j.objects.Form frm = new anywheresoftware.b4j.objects.Form();
            frm.initWithStage(ba, stage, 600, 400);
            ba.raiseEvent(null, "appstart", frm, (String[])getParameters().getRaw().toArray(new String[0]));
        } catch (Throwable t) {
            BA.printException(t, true);
            System.exit(1);
        }
    }
public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static anywheresoftware.b4j.objects.Form _mainform = null;
public static anywheresoftware.b4j.objects.TableViewWrapper _tvwmain = null;
public static anywheresoftware.b4j.objects.ButtonWrapper _btnclose = null;
public static anywheresoftware.b4j.objects.SQL _gsql = null;
public static String _gstrdblocalname = "";
public static String _gstrdbremoteurl = "";
public static String _gstrremoteurl = "";
public static String _gstrtransfer = "";
public static b4j.example.httputils2service _httputils2service = null;
public static b4j.example.dbutils _dbutils = null;
public static String  _appinit() throws Exception{
 //BA.debugLineNum = 29;BA.debugLine="Sub AppInit";
 //BA.debugLineNum = 30;BA.debugLine="downloadFile";
_downloadfile();
 //BA.debugLineNum = 31;BA.debugLine="End Sub";
return "";
}
public static String  _appstart(anywheresoftware.b4j.objects.Form _form1,String[] _args) throws Exception{
 //BA.debugLineNum = 21;BA.debugLine="Sub AppStart (Form1 As Form, Args() As String)";
 //BA.debugLineNum = 22;BA.debugLine="MainForm = Form1";
_mainform = _form1;
 //BA.debugLineNum = 23;BA.debugLine="MainForm.RootPane.LoadLayout(\"B4JHowToSQLiteRemote\") 'Load the layout file.";
_mainform.getRootPane().LoadLayout(ba,"B4JHowToSQLiteRemote");
 //BA.debugLineNum = 24;BA.debugLine="MainForm.Show";
_mainform.Show();
 //BA.debugLineNum = 26;BA.debugLine="AppInit";
_appinit();
 //BA.debugLineNum = 27;BA.debugLine="End Sub";
return "";
}
public static String  _btnclose_action() throws Exception{
 //BA.debugLineNum = 33;BA.debugLine="Sub btnClose_Action";
 //BA.debugLineNum = 34;BA.debugLine="MainForm.Close";
_mainform.Close();
 //BA.debugLineNum = 35;BA.debugLine="End Sub";
return "";
}
public static String  _downloadfile() throws Exception{
b4j.example.httpjob _job = null;
String _filelocal = "";
String _fileurl = "";
 //BA.debugLineNum = 47;BA.debugLine="Sub downloadFile";
 //BA.debugLineNum = 48;BA.debugLine="Log(\"downloadFile :: Start\")";
anywheresoftware.b4a.keywords.Common.Log("downloadFile :: Start");
 //BA.debugLineNum = 49;BA.debugLine="Dim job As HttpJob                                 ' HTTP job for download";
_job = new b4j.example.httpjob();
 //BA.debugLineNum = 50;BA.debugLine="Dim fileLocal As String = gstrDBLocalName           ' Local filename; also used as job name";
_filelocal = _gstrdblocalname;
 //BA.debugLineNum = 51;BA.debugLine="Dim fileURL As String = gstrDBRemoteURL   		  ' Remote filename";
_fileurl = _gstrdbremoteurl;
 //BA.debugLineNum = 52;BA.debugLine="gstrTransfer = \"D\"";
_gstrtransfer = "D";
 //BA.debugLineNum = 53;BA.debugLine="job.Initialize(fileLocal, Me)                      ' Init the job using fileLocal as Jobname";
_job._initialize(ba,_filelocal,main.getObject());
 //BA.debugLineNum = 54;BA.debugLine="job.Download(fileURL)";
_job._download(_fileurl);
 //BA.debugLineNum = 56;BA.debugLine="Log(\"downloadFile :: End\")";
anywheresoftware.b4a.keywords.Common.Log("downloadFile :: End");
 //BA.debugLineNum = 57;BA.debugLine="End Sub";
return "";
}
public static String  _jobdone(b4j.example.httpjob _job) throws Exception{
anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper _out = null;
 //BA.debugLineNum = 77;BA.debugLine="Sub JobDone (Job As HttpJob)";
 //BA.debugLineNum = 78;BA.debugLine="Log(\"JobDone :: Start\")";
anywheresoftware.b4a.keywords.Common.Log("JobDone :: Start");
 //BA.debugLineNum = 80;BA.debugLine="Log(\"-JobName = \" & Job.JobName)";
anywheresoftware.b4a.keywords.Common.Log("-JobName = "+_job._jobname);
 //BA.debugLineNum = 81;BA.debugLine="Log(\"-Success = \" & Job.Success)";
anywheresoftware.b4a.keywords.Common.Log("-Success = "+BA.ObjectToString(_job._success));
 //BA.debugLineNum = 83;BA.debugLine="If Job.Success = True Then";
if (_job._success==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 85;BA.debugLine="If gstrTransfer = \"D\" Then";
if ((_gstrtransfer).equals("D")) { 
 //BA.debugLineNum = 86;BA.debugLine="Dim out As OutputStream = File.OpenOutput(File.DirApp, job.JobName, False)";
_out = new anywheresoftware.b4a.objects.streams.File.OutputStreamWrapper();
_out = anywheresoftware.b4a.keywords.Common.File.OpenOutput(anywheresoftware.b4a.keywords.Common.File.getDirApp(),_job._jobname,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 87;BA.debugLine="File.Copy2(Job.GetInputStream, out)";
anywheresoftware.b4a.keywords.Common.File.Copy2((java.io.InputStream)(_job._getinputstream().getObject()),(java.io.OutputStream)(_out.getObject()));
 //BA.debugLineNum = 88;BA.debugLine="out.Close";
_out.Close();
 //BA.debugLineNum = 89;BA.debugLine="Log(\"-Downloadjob Done. Local file created: \" & Job.JobName & \" (\" & File.DirApp & \")\")";
anywheresoftware.b4a.keywords.Common.Log("-Downloadjob Done. Local file created: "+_job._jobname+" ("+anywheresoftware.b4a.keywords.Common.File.getDirApp()+")");
 }else {
 //BA.debugLineNum = 91;BA.debugLine="Log(\"-Uploadjob Done.\")";
anywheresoftware.b4a.keywords.Common.Log("-Uploadjob Done.");
 };
 }else {
 //BA.debugLineNum = 94;BA.debugLine="Log(\"-Job Error: \" & Job.ErrorMessage)";
anywheresoftware.b4a.keywords.Common.Log("-Job Error: "+_job._errormessage);
 };
 //BA.debugLineNum = 96;BA.debugLine="Job.Release";
_job._release();
 //BA.debugLineNum = 98;BA.debugLine="If gstrTransfer = \"D\" Then";
if ((_gstrtransfer).equals("D")) { 
 //BA.debugLineNum = 99;BA.debugLine="openDB";
_opendb();
 };
 //BA.debugLineNum = 101;BA.debugLine="Log(\"JobDone :: End\")";
anywheresoftware.b4a.keywords.Common.Log("JobDone :: End");
 //BA.debugLineNum = 102;BA.debugLine="End Sub";
return "";
}
public static String  _opendb() throws Exception{
 //BA.debugLineNum = 37;BA.debugLine="Sub openDB";
 //BA.debugLineNum = 38;BA.debugLine="Log(\"openDB :: Start\")";
anywheresoftware.b4a.keywords.Common.Log("openDB :: Start");
 //BA.debugLineNum = 40;BA.debugLine="gSQL.InitializeSQLite(File.DirApp, gstrDBLocalName, False)";
_gsql.InitializeSQLite(anywheresoftware.b4a.keywords.Common.File.getDirApp(),_gstrdblocalname,anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 42;BA.debugLine="DBUtils.ExecuteTableView(gSQL, \"SELECT * FROM contacts\", Null, 0, tvwMain)";
_dbutils._executetableview(_gsql,"SELECT * FROM contacts",(String[])(anywheresoftware.b4a.keywords.Common.Null),(int) (0),_tvwmain);
 //BA.debugLineNum = 43;BA.debugLine="Log(\"openDB :: End\")";
anywheresoftware.b4a.keywords.Common.Log("openDB :: End");
 //BA.debugLineNum = 44;BA.debugLine="End Sub";
return "";
}

private static boolean processGlobalsRun;
public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        b4j.example.httputils2service._process_globals();
main._process_globals();
dbutils._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 8;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 9;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 10;BA.debugLine="Private MainForm As Form";
_mainform = new anywheresoftware.b4j.objects.Form();
 //BA.debugLineNum = 11;BA.debugLine="Private tvwMain As TableView";
_tvwmain = new anywheresoftware.b4j.objects.TableViewWrapper();
 //BA.debugLineNum = 12;BA.debugLine="Private btnClose As Button";
_btnclose = new anywheresoftware.b4j.objects.ButtonWrapper();
 //BA.debugLineNum = 14;BA.debugLine="Dim gSQL As SQL";
_gsql = new anywheresoftware.b4j.objects.SQL();
 //BA.debugLineNum = 15;BA.debugLine="Dim gstrDBLocalName As String = \"rocontactz.db\"";
_gstrdblocalname = "rocontactz.db";
 //BA.debugLineNum = 16;BA.debugLine="Dim gstrDBRemoteURL As String = \"http://www.rwblinn.de/b4j/rocontactz.db\"";
_gstrdbremoteurl = "http://www.rwblinn.de/b4j/rocontactz.db";
 //BA.debugLineNum = 17;BA.debugLine="Dim gstrRemoteURL As String = \"http://www.rwblinn.de/b4j/\"";
_gstrremoteurl = "http://www.rwblinn.de/b4j/";
 //BA.debugLineNum = 18;BA.debugLine="Dim gstrTransfer As String";
_gstrtransfer = "";
 //BA.debugLineNum = 19;BA.debugLine="End Sub";
return "";
}
public static String  _uploadfile() throws Exception{
b4j.example.httpjob _job1 = null;
String _filelocal = "";
String _fileurl = "";
 //BA.debugLineNum = 60;BA.debugLine="Sub uploadFile";
 //BA.debugLineNum = 61;BA.debugLine="Log(\"uploadFile :: Start\")";
anywheresoftware.b4a.keywords.Common.Log("uploadFile :: Start");
 //BA.debugLineNum = 62;BA.debugLine="Dim job1 As HttpJob                                      ' HTTP job for upload";
_job1 = new b4j.example.httpjob();
 //BA.debugLineNum = 63;BA.debugLine="Dim fileLocal As String = gstrDBLocalName              ' Local filename to upload";
_filelocal = _gstrdblocalname;
 //BA.debugLineNum = 64;BA.debugLine="gstrTransfer = \"U\"";
_gstrtransfer = "U";
 //BA.debugLineNum = 68;BA.debugLine="Dim fileURL As String = \"http://\" & gstrRemoteURL & \"/upload.php?FileName=\" & fileLocal";
_fileurl = "http://"+_gstrremoteurl+"/upload.php?FileName="+_filelocal;
 //BA.debugLineNum = 70;BA.debugLine="job1.Initialize(fileLocal, Me)                    ' Init the job using fileLocal as Jobname";
_job1._initialize(ba,_filelocal,main.getObject());
 //BA.debugLineNum = 71;BA.debugLine="job1.PostFile(fileURL, File.DirApp, fileLocal)            ' Post the file to the server script";
_job1._postfile(_fileurl,anywheresoftware.b4a.keywords.Common.File.getDirApp(),_filelocal);
 //BA.debugLineNum = 73;BA.debugLine="Log(\"uploadFile :: End\")";
anywheresoftware.b4a.keywords.Common.Log("uploadFile :: End");
 //BA.debugLineNum = 74;BA.debugLine="End Sub";
return "";
}
}
