package b4j.example;

import anywheresoftware.b4a.BA;

public class dbutils extends Object{
public static dbutils mostCurrent = new dbutils();
public static BA ba;
static {
		ba = new  anywheresoftware.b4j.objects.FxBA("b4j.example", "b4j.example.dbutils", null);
		ba.loadHtSubs(dbutils.class);
        if (ba.getClass().getName().endsWith("ShellBA")) {
			
			ba.raiseEvent2(null, true, "SHELL", false);
			ba.raiseEvent2(null, true, "CREATE", true, "b4j.example.dbutils", ba);
		}
	}
    public static Class<?> getObject() {
		return dbutils.class;
	}

 public static anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4j.objects.JFX _fx = null;
public static String _db_real = "";
public static String _db_integer = "";
public static String _db_blob = "";
public static String _db_text = "";
public static b4j.example.httputils2service _httputils2service = null;
public static b4j.example.main _main = null;
public static String  _createtable(anywheresoftware.b4j.objects.SQL _sql,String _tablename,anywheresoftware.b4a.objects.collections.Map _fieldsandtypes,String _primarykey) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
int _i = 0;
String _field = "";
String _ftype = "";
String _query = "";
 //BA.debugLineNum = 15;BA.debugLine="Public Sub CreateTable(SQL As SQL, TableName As String, FieldsAndTypes As Map, PrimaryKey As String)";
 //BA.debugLineNum = 16;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 17;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 18;BA.debugLine="sb.Append(\"(\")";
_sb.Append("(");
 //BA.debugLineNum = 19;BA.debugLine="For i = 0 To FieldsAndTypes.Size - 1";
{
final int step12 = 1;
final int limit12 = (int) (_fieldsandtypes.getSize()-1);
for (_i = (int) (0); (step12 > 0 && _i <= limit12) || (step12 < 0 && _i >= limit12); _i = ((int)(0 + _i + step12))) {
 //BA.debugLineNum = 20;BA.debugLine="Dim field, ftype As String";
_field = "";
_ftype = "";
 //BA.debugLineNum = 21;BA.debugLine="field = FieldsAndTypes.GetKeyAt(i)";
_field = BA.ObjectToString(_fieldsandtypes.GetKeyAt(_i));
 //BA.debugLineNum = 22;BA.debugLine="ftype = FieldsAndTypes.GetValueAt(i)";
_ftype = BA.ObjectToString(_fieldsandtypes.GetValueAt(_i));
 //BA.debugLineNum = 23;BA.debugLine="If i > 0 Then sb.Append(\", \")";
if (_i>0) { 
_sb.Append(", ");};
 //BA.debugLineNum = 24;BA.debugLine="sb.Append(\"[\").Append(field).Append(\"] \").Append(ftype)";
_sb.Append("[").Append(_field).Append("] ").Append(_ftype);
 //BA.debugLineNum = 25;BA.debugLine="If field = PrimaryKey Then sb.Append(\" PRIMARY KEY\")";
if ((_field).equals(_primarykey)) { 
_sb.Append(" PRIMARY KEY");};
 }
};
 //BA.debugLineNum = 27;BA.debugLine="sb.Append(\")\")";
_sb.Append(")");
 //BA.debugLineNum = 28;BA.debugLine="Dim query As String";
_query = "";
 //BA.debugLineNum = 29;BA.debugLine="query = \"CREATE TABLE IF NOT EXISTS [\" & TableName & \"] \" & sb.ToString";
_query = "CREATE TABLE IF NOT EXISTS ["+_tablename+"] "+_sb.ToString();
 //BA.debugLineNum = 31;BA.debugLine="SQL.ExecNonQuery(query)";
_sql.ExecNonQuery(_query);
 //BA.debugLineNum = 32;BA.debugLine="End Sub";
return "";
}
public static String  _droptable(anywheresoftware.b4j.objects.SQL _sql,String _tablename) throws Exception{
String _query = "";
 //BA.debugLineNum = 35;BA.debugLine="Public Sub DropTable(SQL As SQL, TableName As String)";
 //BA.debugLineNum = 36;BA.debugLine="Dim query As String";
_query = "";
 //BA.debugLineNum = 37;BA.debugLine="query = \"DROP TABLE IF EXISTS [\" & TableName & \"]\"";
_query = "DROP TABLE IF EXISTS ["+_tablename+"]";
 //BA.debugLineNum = 39;BA.debugLine="SQL.ExecNonQuery(query)";
_sql.ExecNonQuery(_query);
 //BA.debugLineNum = 40;BA.debugLine="End Sub";
return "";
}
public static String  _executelist(anywheresoftware.b4j.objects.SQL _sql,String _query,String[] _stringargs,int _limit,anywheresoftware.b4a.objects.collections.List _list1) throws Exception{
anywheresoftware.b4a.objects.collections.List _table = null;
String[] _cols = null;
int _i = 0;
 //BA.debugLineNum = 205;BA.debugLine="Public Sub ExecuteList(SQL As SQL, Query As String, StringArgs() As String, Limit As Int, List1 As List)";
 //BA.debugLineNum = 206;BA.debugLine="List1.Clear";
_list1.Clear();
 //BA.debugLineNum = 207;BA.debugLine="Dim Table As List";
_table = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 208;BA.debugLine="Table = ExecuteMemoryTable(SQL, Query, StringArgs, Limit)";
_table = _executememorytable(_sql,_query,_stringargs,_limit);
 //BA.debugLineNum = 209;BA.debugLine="If Table.Size = 0 Then Return";
if (_table.getSize()==0) { 
if (true) return "";};
 //BA.debugLineNum = 210;BA.debugLine="Dim Cols() As String";
_cols = new String[(int) (0)];
java.util.Arrays.fill(_cols,"");
 //BA.debugLineNum = 211;BA.debugLine="For i = 0 To Table.Size - 1";
{
final int step164 = 1;
final int limit164 = (int) (_table.getSize()-1);
for (_i = (int) (0); (step164 > 0 && _i <= limit164) || (step164 < 0 && _i >= limit164); _i = ((int)(0 + _i + step164))) {
 //BA.debugLineNum = 212;BA.debugLine="Cols = Table.Get(i)";
_cols = (String[])(_table.Get(_i));
 //BA.debugLineNum = 213;BA.debugLine="List1.Add(Cols(0))";
_list1.Add((Object)(_cols[(int) (0)]));
 }
};
 //BA.debugLineNum = 215;BA.debugLine="End Sub";
return "";
}
public static anywheresoftware.b4a.objects.collections.Map  _executemap(anywheresoftware.b4j.objects.SQL _sql,String _query,String[] _stringargs) throws Exception{
anywheresoftware.b4a.objects.collections.Map _res = null;
anywheresoftware.b4j.objects.SQL.ResultSetWrapper _cur = null;
int _i = 0;
 //BA.debugLineNum = 183;BA.debugLine="Public Sub ExecuteMap(SQL As SQL, Query As String, StringArgs() As String) As Map";
 //BA.debugLineNum = 184;BA.debugLine="Dim res As Map";
_res = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 185;BA.debugLine="Dim cur As ResultSet";
_cur = new anywheresoftware.b4j.objects.SQL.ResultSetWrapper();
 //BA.debugLineNum = 186;BA.debugLine="If StringArgs <> Null Then";
if (_stringargs!= null) { 
 //BA.debugLineNum = 187;BA.debugLine="cur = SQL.ExecQuery2(Query, StringArgs)";
_cur = _sql.ExecQuery2(_query,anywheresoftware.b4a.keywords.Common.ArrayToList(_stringargs));
 }else {
 //BA.debugLineNum = 189;BA.debugLine="cur = SQL.ExecQuery(Query)";
_cur = _sql.ExecQuery(_query);
 };
 //BA.debugLineNum = 192;BA.debugLine="If cur.NextRow = False Then";
if (_cur.NextRow()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 194;BA.debugLine="Return res";
if (true) return _res;
 };
 //BA.debugLineNum = 196;BA.debugLine="res.Initialize";
_res.Initialize();
 //BA.debugLineNum = 197;BA.debugLine="For i = 0 To cur.ColumnCount - 1";
{
final int step152 = 1;
final int limit152 = (int) (_cur.getColumnCount()-1);
for (_i = (int) (0); (step152 > 0 && _i <= limit152) || (step152 < 0 && _i >= limit152); _i = ((int)(0 + _i + step152))) {
 //BA.debugLineNum = 198;BA.debugLine="res.Put(cur.GetColumnName(i).ToLowerCase, cur.GetString2(i))";
_res.Put((Object)(_cur.GetColumnName(_i).toLowerCase()),(Object)(_cur.GetString2(_i)));
 }
};
 //BA.debugLineNum = 200;BA.debugLine="cur.Close";
_cur.Close();
 //BA.debugLineNum = 201;BA.debugLine="Return res";
if (true) return _res;
 //BA.debugLineNum = 202;BA.debugLine="End Sub";
return null;
}
public static anywheresoftware.b4a.objects.collections.List  _executememorytable(anywheresoftware.b4j.objects.SQL _sql,String _query,String[] _stringargs,int _limit) throws Exception{
anywheresoftware.b4j.objects.SQL.ResultSetWrapper _cur = null;
anywheresoftware.b4a.objects.collections.List _table = null;
String[] _values = null;
int _col = 0;
 //BA.debugLineNum = 158;BA.debugLine="Public Sub ExecuteMemoryTable(SQL As SQL, Query As String, StringArgs() As String, Limit As Int) As List";
 //BA.debugLineNum = 159;BA.debugLine="Dim cur As ResultSet";
_cur = new anywheresoftware.b4j.objects.SQL.ResultSetWrapper();
 //BA.debugLineNum = 160;BA.debugLine="If StringArgs = Null Then";
if (_stringargs== null) { 
 //BA.debugLineNum = 161;BA.debugLine="Dim StringArgs(0) As String";
_stringargs = new String[(int) (0)];
java.util.Arrays.fill(_stringargs,"");
 };
 //BA.debugLineNum = 163;BA.debugLine="cur = SQL.ExecQuery2(Query, StringArgs)";
_cur = _sql.ExecQuery2(_query,anywheresoftware.b4a.keywords.Common.ArrayToList(_stringargs));
 //BA.debugLineNum = 165;BA.debugLine="Dim table As List";
_table = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 166;BA.debugLine="table.Initialize";
_table.Initialize();
 //BA.debugLineNum = 167;BA.debugLine="Do While cur.NextRow";
while (_cur.NextRow()) {
 //BA.debugLineNum = 168;BA.debugLine="Dim values(cur.ColumnCount) As String";
_values = new String[_cur.getColumnCount()];
java.util.Arrays.fill(_values,"");
 //BA.debugLineNum = 169;BA.debugLine="For col = 0 To cur.ColumnCount - 1";
{
final int step131 = 1;
final int limit131 = (int) (_cur.getColumnCount()-1);
for (_col = (int) (0); (step131 > 0 && _col <= limit131) || (step131 < 0 && _col >= limit131); _col = ((int)(0 + _col + step131))) {
 //BA.debugLineNum = 170;BA.debugLine="values(col) = cur.GetString2(col)";
_values[_col] = _cur.GetString2(_col);
 }
};
 //BA.debugLineNum = 172;BA.debugLine="table.Add(values)";
_table.Add((Object)(_values));
 //BA.debugLineNum = 173;BA.debugLine="If Limit > 0 AND table.Size >= Limit Then Exit";
if (_limit>0 && _table.getSize()>=_limit) { 
if (true) break;};
 }
;
 //BA.debugLineNum = 175;BA.debugLine="cur.Close";
_cur.Close();
 //BA.debugLineNum = 176;BA.debugLine="Return table";
if (true) return _table;
 //BA.debugLineNum = 177;BA.debugLine="End Sub";
return null;
}
public static String  _executetableview(anywheresoftware.b4j.objects.SQL _sql,String _query,String[] _stringargs,int _limit,anywheresoftware.b4j.objects.TableViewWrapper _tableview1) throws Exception{
anywheresoftware.b4j.objects.SQL.ResultSetWrapper _cur = null;
anywheresoftware.b4a.objects.collections.List _cols = null;
int _i = 0;
String[] _values = null;
int _col = 0;
 //BA.debugLineNum = 217;BA.debugLine="Public Sub ExecuteTableView(SQL As SQL, Query As String, StringArgs() As String, Limit As Int, _ 	TableView1 As TableView)";
 //BA.debugLineNum = 219;BA.debugLine="TableView1.Items.Clear";
_tableview1.getItems().Clear();
 //BA.debugLineNum = 220;BA.debugLine="Dim cur As ResultSet";
_cur = new anywheresoftware.b4j.objects.SQL.ResultSetWrapper();
 //BA.debugLineNum = 221;BA.debugLine="If StringArgs = Null Then";
if (_stringargs== null) { 
 //BA.debugLineNum = 222;BA.debugLine="Dim StringArgs(0) As String";
_stringargs = new String[(int) (0)];
java.util.Arrays.fill(_stringargs,"");
 };
 //BA.debugLineNum = 224;BA.debugLine="cur = SQL.ExecQuery2(Query, StringArgs)";
_cur = _sql.ExecQuery2(_query,anywheresoftware.b4a.keywords.Common.ArrayToList(_stringargs));
 //BA.debugLineNum = 225;BA.debugLine="Dim cols As List";
_cols = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 226;BA.debugLine="cols.Initialize";
_cols.Initialize();
 //BA.debugLineNum = 227;BA.debugLine="For i = 0 To cur.ColumnCount - 1";
{
final int step178 = 1;
final int limit178 = (int) (_cur.getColumnCount()-1);
for (_i = (int) (0); (step178 > 0 && _i <= limit178) || (step178 < 0 && _i >= limit178); _i = ((int)(0 + _i + step178))) {
 //BA.debugLineNum = 228;BA.debugLine="cols.Add(cur.GetColumnName(i))";
_cols.Add((Object)(_cur.GetColumnName(_i)));
 }
};
 //BA.debugLineNum = 230;BA.debugLine="TableView1.SetColumns(cols)";
_tableview1.SetColumns(_cols);
 //BA.debugLineNum = 231;BA.debugLine="Do While cur.NextRow";
while (_cur.NextRow()) {
 //BA.debugLineNum = 232;BA.debugLine="Dim values(cur.ColumnCount) As String";
_values = new String[_cur.getColumnCount()];
java.util.Arrays.fill(_values,"");
 //BA.debugLineNum = 233;BA.debugLine="For col = 0 To cur.ColumnCount - 1";
{
final int step184 = 1;
final int limit184 = (int) (_cur.getColumnCount()-1);
for (_col = (int) (0); (step184 > 0 && _col <= limit184) || (step184 < 0 && _col >= limit184); _col = ((int)(0 + _col + step184))) {
 //BA.debugLineNum = 234;BA.debugLine="values(col) = cur.GetString2(col)";
_values[_col] = _cur.GetString2(_col);
 }
};
 //BA.debugLineNum = 236;BA.debugLine="TableView1.Items.Add(values)";
_tableview1.getItems().Add((Object)(_values));
 //BA.debugLineNum = 237;BA.debugLine="If Limit > 0 AND TableView1.Items.Size >= Limit Then Exit";
if (_limit>0 && _tableview1.getItems().getSize()>=_limit) { 
if (true) break;};
 }
;
 //BA.debugLineNum = 239;BA.debugLine="cur.Close";
_cur.Close();
 //BA.debugLineNum = 240;BA.debugLine="End Sub";
return "";
}
public static String  _insertmaps(anywheresoftware.b4j.objects.SQL _sql,String _tablename,anywheresoftware.b4a.objects.collections.List _listofmaps) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _columns = null;
anywheresoftware.b4a.keywords.StringBuilderWrapper _values = null;
int _i1 = 0;
anywheresoftware.b4a.objects.collections.List _listofvalues = null;
anywheresoftware.b4a.objects.collections.Map _m = null;
int _i2 = 0;
String _col = "";
Object _value = null;
 //BA.debugLineNum = 46;BA.debugLine="Public Sub InsertMaps(SQL As SQL, TableName As String, ListOfMaps As List)";
 //BA.debugLineNum = 47;BA.debugLine="Dim sb, columns, values As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
_columns = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
_values = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 49;BA.debugLine="If ListOfMaps.Size > 1 AND ListOfMaps.Get(0) = ListOfMaps.Get(1) Then";
if (_listofmaps.getSize()>1 && (_listofmaps.Get((int) (0))).equals(_listofmaps.Get((int) (1)))) { 
 //BA.debugLineNum = 51;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 53;BA.debugLine="SQL.BeginTransaction";
_sql.BeginTransaction();
 //BA.debugLineNum = 54;BA.debugLine="Try";
try { //BA.debugLineNum = 55;BA.debugLine="For i1 = 0 To ListOfMaps.Size - 1";
{
final int step37 = 1;
final int limit37 = (int) (_listofmaps.getSize()-1);
for (_i1 = (int) (0); (step37 > 0 && _i1 <= limit37) || (step37 < 0 && _i1 >= limit37); _i1 = ((int)(0 + _i1 + step37))) {
 //BA.debugLineNum = 56;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 57;BA.debugLine="columns.Initialize";
_columns.Initialize();
 //BA.debugLineNum = 58;BA.debugLine="values.Initialize";
_values.Initialize();
 //BA.debugLineNum = 59;BA.debugLine="Dim listOfValues As List";
_listofvalues = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 60;BA.debugLine="listOfValues.Initialize";
_listofvalues.Initialize();
 //BA.debugLineNum = 61;BA.debugLine="sb.Append(\"INSERT INTO [\" & TableName & \"] (\")";
_sb.Append("INSERT INTO ["+_tablename+"] (");
 //BA.debugLineNum = 62;BA.debugLine="Dim m As Map";
_m = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 63;BA.debugLine="m = ListOfMaps.Get(i1)";
_m.setObject((anywheresoftware.b4a.objects.collections.Map.MyMap)(_listofmaps.Get(_i1)));
 //BA.debugLineNum = 64;BA.debugLine="For i2 = 0 To m.Size - 1";
{
final int step46 = 1;
final int limit46 = (int) (_m.getSize()-1);
for (_i2 = (int) (0); (step46 > 0 && _i2 <= limit46) || (step46 < 0 && _i2 >= limit46); _i2 = ((int)(0 + _i2 + step46))) {
 //BA.debugLineNum = 65;BA.debugLine="Dim col As String";
_col = "";
 //BA.debugLineNum = 66;BA.debugLine="Dim value As Object";
_value = new Object();
 //BA.debugLineNum = 67;BA.debugLine="col = m.GetKeyAt(i2)";
_col = BA.ObjectToString(_m.GetKeyAt(_i2));
 //BA.debugLineNum = 68;BA.debugLine="value = m.GetValueAt(i2)";
_value = _m.GetValueAt(_i2);
 //BA.debugLineNum = 69;BA.debugLine="If i2 > 0 Then";
if (_i2>0) { 
 //BA.debugLineNum = 70;BA.debugLine="columns.Append(\", \")";
_columns.Append(", ");
 //BA.debugLineNum = 71;BA.debugLine="values.Append(\", \")";
_values.Append(", ");
 };
 //BA.debugLineNum = 73;BA.debugLine="columns.Append(\"[\")";
_columns.Append("[");
 //BA.debugLineNum = 74;BA.debugLine="columns.Append(col)";
_columns.Append(_col);
 //BA.debugLineNum = 75;BA.debugLine="columns.Append(\"]\")";
_columns.Append("]");
 //BA.debugLineNum = 77;BA.debugLine="values.Append(\"?\")";
_values.Append("?");
 //BA.debugLineNum = 78;BA.debugLine="listOfValues.Add(value)";
_listofvalues.Add(_value);
 }
};
 //BA.debugLineNum = 80;BA.debugLine="sb.Append(columns.ToString)";
_sb.Append(_columns.ToString());
 //BA.debugLineNum = 81;BA.debugLine="sb.Append(\") VALUES (\")";
_sb.Append(") VALUES (");
 //BA.debugLineNum = 82;BA.debugLine="sb.Append(values.ToString)";
_sb.Append(_values.ToString());
 //BA.debugLineNum = 83;BA.debugLine="sb.Append(\")\")";
_sb.Append(")");
 //BA.debugLineNum = 85;BA.debugLine="SQL.ExecNonQuery2(sb.ToString, listOfValues)";
_sql.ExecNonQuery2(_sb.ToString(),_listofvalues);
 }
};
 //BA.debugLineNum = 87;BA.debugLine="SQL.TransactionSuccessful";
_sql.TransactionSuccessful();
 } 
       catch (Exception e69) {
			ba.setLastException(e69); //BA.debugLineNum = 89;BA.debugLine="Log(LastException)";
anywheresoftware.b4a.keywords.Common.Log(BA.ObjectToString(anywheresoftware.b4a.keywords.Common.LastException(ba)));
 //BA.debugLineNum = 90;BA.debugLine="SQL.Rollback";
_sql.Rollback();
 };
 //BA.debugLineNum = 92;BA.debugLine="End Sub";
return "";
}
public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 2;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 3;BA.debugLine="Private fx As JFX";
_fx = new anywheresoftware.b4j.objects.JFX();
 //BA.debugLineNum = 4;BA.debugLine="Public DB_REAL, DB_INTEGER, DB_BLOB, DB_TEXT As String";
_db_real = "";
_db_integer = "";
_db_blob = "";
_db_text = "";
 //BA.debugLineNum = 5;BA.debugLine="DB_REAL = \"REAL\"";
_db_real = "REAL";
 //BA.debugLineNum = 6;BA.debugLine="DB_INTEGER = \"INTEGER\"";
_db_integer = "INTEGER";
 //BA.debugLineNum = 7;BA.debugLine="DB_BLOB = \"BLOB\"";
_db_blob = "BLOB";
 //BA.debugLineNum = 8;BA.debugLine="DB_TEXT = \"TEXT\"";
_db_text = "TEXT";
 //BA.debugLineNum = 9;BA.debugLine="End Sub";
return "";
}
public static String  _updaterecord(anywheresoftware.b4j.objects.SQL _sql,String _tablename,String _field,Object _newvalue,anywheresoftware.b4a.objects.collections.Map _wherefieldequals) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
anywheresoftware.b4a.objects.collections.List _args = null;
int _i = 0;
 //BA.debugLineNum = 96;BA.debugLine="Public Sub UpdateRecord(SQL As SQL, TableName As String, Field As String, NewValue As Object, _ 	WhereFieldEquals As Map)";
 //BA.debugLineNum = 98;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 99;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 100;BA.debugLine="sb.Append(\"UPDATE [\").Append(TableName).Append(\"] SET [\").Append(Field).Append(\"] = ? WHERE \")";
_sb.Append("UPDATE [").Append(_tablename).Append("] SET [").Append(_field).Append("] = ? WHERE ");
 //BA.debugLineNum = 101;BA.debugLine="If WhereFieldEquals.Size = 0 Then";
if (_wherefieldequals.getSize()==0) { 
 //BA.debugLineNum = 102;BA.debugLine="Log(\"WhereFieldEquals map empty!\")";
anywheresoftware.b4a.keywords.Common.Log("WhereFieldEquals map empty!");
 //BA.debugLineNum = 103;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 105;BA.debugLine="Dim args As List";
_args = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 106;BA.debugLine="args.Initialize";
_args.Initialize();
 //BA.debugLineNum = 107;BA.debugLine="args.Add(NewValue)";
_args.Add(_newvalue);
 //BA.debugLineNum = 108;BA.debugLine="For i = 0 To WhereFieldEquals.Size - 1";
{
final int step84 = 1;
final int limit84 = (int) (_wherefieldequals.getSize()-1);
for (_i = (int) (0); (step84 > 0 && _i <= limit84) || (step84 < 0 && _i >= limit84); _i = ((int)(0 + _i + step84))) {
 //BA.debugLineNum = 109;BA.debugLine="If i > 0 Then sb.Append(\" AND \")";
if (_i>0) { 
_sb.Append(" AND ");};
 //BA.debugLineNum = 110;BA.debugLine="sb.Append(\"[\").Append(WhereFieldEquals.GetKeyAt(i)).Append(\"] = ?\")";
_sb.Append("[").Append(BA.ObjectToString(_wherefieldequals.GetKeyAt(_i))).Append("] = ?");
 //BA.debugLineNum = 111;BA.debugLine="args.Add(WhereFieldEquals.GetValueAt(i))";
_args.Add(_wherefieldequals.GetValueAt(_i));
 }
};
 //BA.debugLineNum = 114;BA.debugLine="SQL.ExecNonQuery2(sb.ToString, args)";
_sql.ExecNonQuery2(_sb.ToString(),_args);
 //BA.debugLineNum = 115;BA.debugLine="End Sub";
return "";
}
public static String  _updaterecord2(anywheresoftware.b4j.objects.SQL _sql,String _tablename,anywheresoftware.b4a.objects.collections.Map _fields,anywheresoftware.b4a.objects.collections.Map _wherefieldequals) throws Exception{
anywheresoftware.b4a.keywords.StringBuilderWrapper _sb = null;
anywheresoftware.b4a.objects.collections.List _args = null;
int _i = 0;
 //BA.debugLineNum = 119;BA.debugLine="Public Sub UpdateRecord2(SQL As SQL, TableName As String, Fields As Map, WhereFieldEquals As Map)";
 //BA.debugLineNum = 120;BA.debugLine="If WhereFieldEquals.Size = 0 Then";
if (_wherefieldequals.getSize()==0) { 
 //BA.debugLineNum = 122;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 124;BA.debugLine="If Fields.Size = 0 Then";
if (_fields.getSize()==0) { 
 //BA.debugLineNum = 126;BA.debugLine="Return";
if (true) return "";
 };
 //BA.debugLineNum = 128;BA.debugLine="Dim sb As StringBuilder";
_sb = new anywheresoftware.b4a.keywords.StringBuilderWrapper();
 //BA.debugLineNum = 129;BA.debugLine="sb.Initialize";
_sb.Initialize();
 //BA.debugLineNum = 130;BA.debugLine="sb.Append(\"UPDATE [\").Append(TableName).Append(\"] SET \")";
_sb.Append("UPDATE [").Append(_tablename).Append("] SET ");
 //BA.debugLineNum = 131;BA.debugLine="Dim args As List";
_args = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 132;BA.debugLine="args.Initialize";
_args.Initialize();
 //BA.debugLineNum = 133;BA.debugLine="For i=0 To Fields.Size-1";
{
final int step103 = 1;
final int limit103 = (int) (_fields.getSize()-1);
for (_i = (int) (0); (step103 > 0 && _i <= limit103) || (step103 < 0 && _i >= limit103); _i = ((int)(0 + _i + step103))) {
 //BA.debugLineNum = 134;BA.debugLine="If i<>Fields.Size-1 Then";
if (_i!=_fields.getSize()-1) { 
 //BA.debugLineNum = 135;BA.debugLine="sb.Append(\"[\").Append(Fields.GetKeyAt(i)).Append(\"]=?,\")";
_sb.Append("[").Append(BA.ObjectToString(_fields.GetKeyAt(_i))).Append("]=?,");
 }else {
 //BA.debugLineNum = 137;BA.debugLine="sb.Append(\"[\").Append(Fields.GetKeyAt(i)).Append(\"]=?\")";
_sb.Append("[").Append(BA.ObjectToString(_fields.GetKeyAt(_i))).Append("]=?");
 };
 //BA.debugLineNum = 139;BA.debugLine="args.Add(Fields.GetValueAt(i))";
_args.Add(_fields.GetValueAt(_i));
 }
};
 //BA.debugLineNum = 142;BA.debugLine="sb.Append(\" WHERE \")";
_sb.Append(" WHERE ");
 //BA.debugLineNum = 143;BA.debugLine="For i = 0 To WhereFieldEquals.Size - 1";
{
final int step112 = 1;
final int limit112 = (int) (_wherefieldequals.getSize()-1);
for (_i = (int) (0); (step112 > 0 && _i <= limit112) || (step112 < 0 && _i >= limit112); _i = ((int)(0 + _i + step112))) {
 //BA.debugLineNum = 144;BA.debugLine="If i > 0 Then";
if (_i>0) { 
 //BA.debugLineNum = 145;BA.debugLine="sb.Append(\" AND \")";
_sb.Append(" AND ");
 };
 //BA.debugLineNum = 147;BA.debugLine="sb.Append(\"[\").Append(WhereFieldEquals.GetKeyAt(i)).Append(\"] = ?\")";
_sb.Append("[").Append(BA.ObjectToString(_wherefieldequals.GetKeyAt(_i))).Append("] = ?");
 //BA.debugLineNum = 148;BA.debugLine="args.Add(WhereFieldEquals.GetValueAt(i))";
_args.Add(_wherefieldequals.GetValueAt(_i));
 }
};
 //BA.debugLineNum = 151;BA.debugLine="SQL.ExecNonQuery2(sb.ToString, args)";
_sql.ExecNonQuery2(_sb.ToString(),_args);
 //BA.debugLineNum = 152;BA.debugLine="End Sub";
return "";
}
}
