-B4J Project B4JHowTo WebView
Copyright (c) 2015 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtowebview.zip|B4JHowTo WebView TryIt(B4J Open Source)>

-Description
Various examples using JavaFX WebView.

WebViewEx1:
Show the various API methods for a WebView.

WebViewEx2:
TryIt type of app. 
Shows a splitpane with left a textarea in which HTML code can be defined ("HTML Editor").
On the right a WebView to display the content of the textarea as HTML.

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
* This WebApp example is based upon B4J v2.x.
* To learn more, read the source files. These are well commented.
* Additional Libraries: JavaObject

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
20150401
FIX:Paste at cursorposition
FIX:ComboBox CSS style
20150311
NEW:First version
