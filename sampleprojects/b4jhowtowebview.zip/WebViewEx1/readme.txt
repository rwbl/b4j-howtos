-B4J Project B4JHowTo-WebView
Copyright (c) 2014 by Robert W.B. Linn, Pinneberg, Germany, <!http://www.rwblinn.de> .
This app is made available under the terms of the Mozilla Public License 2.0 ( <!https://www.mozilla.org/MPL/2.0/> ).
More info about B4J <!http://www.basic4ppc.com/android/b4j.html|here> .

-Download
* <!file://b4j/b4jhowto/examples/b4jhowtowebview.zip|B4JHowTo-WebView (B4J Open Source)>

-Description
This App is an example of using B4J WebView.
The example makes heavily use of JavaObjects to execute methods.

-Installation
Unpack the zip file and load the b4j file in B4J.

-Notes
* Libararies used: Standard jCore and jFX. Ensure to have jFX 2.01 or higher!
* ToDo: See project file ToDo region

More information to find <!http://www.rwblinn.de|here> .
Many thanks for your interest. Any improvements or further ideas are welcomed.

-Change Log
(+) New, (*) Improved, (-) Removed
<!linie>
20140708
(+) First version
